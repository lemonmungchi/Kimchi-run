using System;
using System.Collections.Generic;
using UnityEngine;

public class GameManager
{
    public Define.ThisGameis thisGameis { get; set; }

    // 플레이어는 하나뿐이니까
    private GameObject _player;

    // 빌딩 프리팹들을 저장할 리스트
    private List<GameObject> _buildings;

    // SpawningPool 등에서 빌딩이 추가/삭제되는 것을 알리기 위한 이벤트
    public Action<int> OnSpawnEvent;

    /// <summary>
    /// 플레이어를 찾기 위한 함수
    /// </summary>
    /// <returns></returns>
    public GameObject GetPlayer()
    {
        return _player;
    }

    /// <summary>
    /// GameObject(빌딩, 플레이어 등)를 생성/등록하는 함수
    /// </summary>
    public GameObject Spawn(Define.WorldObject type, string path, Transform parent = null)
    {
        // 기존 방식 (Instantiate by path)
        GameObject go = Managers.Resource.Instantiate(path, parent);

        switch (type)
        {
            case Define.WorldObject._buildings:
                _buildings.Add(go);
                OnSpawnEvent?.Invoke(1);
                break;

            case Define.WorldObject.Player:
                _player = go;
                break;
        }
        return go;
    }

    /// <summary>
    /// 인자로 받은 GameObject의 타입 반환
    /// </summary>
    public Define.WorldObject GetWorldObjectType(GameObject go)
    {
        // 예시: 실제 구현 시, 
        // BaseController 등으로부터 WorldObjectType을 가져오거나,
        // 프리팹 태그, 레이어 등을 통해 식별 가능
        return Define.WorldObject.Unknown;
    }

    /// <summary>
    /// GameObject를 삭제하는 함수
    /// </summary>
    public void Despawn(GameObject go)
    {
        Define.WorldObject type = GetWorldObjectType(go);

        switch (type)
        {
            case Define.WorldObject._buildings:
                if (_buildings.Contains(go))
                {
                    _buildings.Remove(go);
                    OnSpawnEvent?.Invoke(-1);
                }
                break;

            case Define.WorldObject.Player:
                if (_player == go)
                    _player = null;
                break;
        }

        Managers.Resource.Destroy(go);
    }

    /// <summary>
    /// GameManager 초기화 함수
    /// </summary>
    public void Init()
    {
        // 씬에 존재하는 "Player" 오브젝트 찾기
        _player = GameObject.Find("Player");

        // 1) 빌딩 프리팹들을 모두 로드
        GameObject[] buildingPrefabs = Resources.LoadAll<GameObject>("Prefabs/Buildings");
        _buildings = new List<GameObject>(buildingPrefabs);

        // 2) 오브젝트 풀 생성
        //    (모든 빌딩 프리팹을 PoolManager에 등록, 초기 수량 5개씩 예시)
        foreach (GameObject buildingPrefab in buildingPrefabs)
        {
            Managers.Pool.CreatePool(buildingPrefab, 1);
        }

        Debug.Log($"[GameManager] Init complete! " +
                  $"Loaded {_buildings.Count} building prefabs from 'Resources/Prefabs/'.");
    }
}
